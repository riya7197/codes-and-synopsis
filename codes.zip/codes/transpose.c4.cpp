#include<stdio.h>
int main()
{
	int m,n,matrix[i][j],i,j,transpose[i][j];
	
	printf("enter the number of rows and columns :\n");
	scanf("%d%d",&m,&n);
	
	printf("enter the elements of the matrix\n",);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("index values are [%d][%d]=",i,j);
			scanf("%d",&matrix[i][j]);
		}
	}
	printf("original value of the matrix\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("matrix is %d \t",matrix[i][j]);
			printf("\n");
}
}
}
