#include<stdio.h>
void main()
{
	void multi();
	multi();
	getch();
}
	void multi()
	{
		int a,b,c;
		printf("enter the value of a,b");
		scanf("%d%d",&a,&b);
		c=a*b;
		printf("display c:%d",c);
	}
