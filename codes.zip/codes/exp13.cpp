#include<iostream>
using namespace std;
class function_call
{
	public:
		int x,y;
		int add(int a,int b)
		{
			int sum;
			x=a;
			y=b;
			sum=x+y;
			cout<<endl<<"ADDITION OF TWO INTEGER[USING CALL BY VALUE] IS:"<<sum<<endl;
			cout<<"\n*****************\n"<<endl;
		}
		int multiply(int *a,int*b)
		{
			int mul;
			x=*a;
			y=*b;
			mul=x*y;
			cout<<"MULTIPLICATION OF TWO INTEGER[USING CALL BY ADDRESS] IS:"<<mul<<endl;
			cout<<"\n*****************\n"<<endl;
		}
		int divide(int &a, int &b)
		{
			int div;
			x=a;
			y=b;
			div=x/y;
			cout<<"DIVISION OF TWO INTEGER[USING CALL BY REFERENCE] IS:"<<div<<endl;
			cout<<"\n*****************\n"<<endl;
		}
};
int main()
{
	int n1,n2;
	cout<<"RIYA -2210997197"<<endl;
	cout<<endl;
	
	cout<<"Enter the value of two integer is:"<<endl;
	cout<<"first integer is:";
	cin>>n1;
	cout<<"second integer is:";
	cin>>n2;
	function_call obj;
	obj.add(n1,n2);
	obj.multiply(&n1,&n2);
	obj.divide(n1,n2);
}
