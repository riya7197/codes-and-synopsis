#include<iostream>
using namespace std;
 class a
 {
 	int a,b;
 	public:
 		void get()
 		{
 			cout<<"enter the values of  a and b"<<endl;
 			cin>>a>>b;
 			
	 }
 };
 class b:public a
 {
 	public:
 		void disp()
		 {
		 	cout <<" value of a is "<<a<<endl;
		 	cout <<"value of b is "<<b<<endl;
		  } 
 };
 int main()
 {
 	a ob;
 	ob.get();
	  }
