#include<stdio.h>
int main()
{
   int a=50;
   int *p;
   p=&a;
   printf("address of p is %p\n",p);
   printf("adress of a is :%p\n",a);
   p=p+1;
   printf("after increment value of p is :%p\n",p+1);
}
