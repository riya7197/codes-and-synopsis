#include<stdio.h>
int change(int,int);
int main()
{
{
	int a,b;
	printf("enter the value of a,b");
	scanf("%d%d",&a,&b);
	change(a,b);
	printf("changed value of a is : %d\n and changed value of b is :%d\n",a,b);
}
int change(int a,int b)
{
	int k;
	k=a;
	a=b;
	k=b;
	printf("display the value of a:%d\n and b is :%d\n",a,b);
}
}
	
	
	
	

