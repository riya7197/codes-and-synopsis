#include<stdio.h>
int main()
{
	int m,n,i,j;
	int mat[i][j],transpose[i][j];
	
	printf("enter the number of rows and columns :\n");
	scanf("%d%d",&m,&n);
	
	printf("enter the elements of the matrix\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("index values are [%d][%d]=",i,j);
			scanf("%d",&mat[i][j]);
		}
	}
	printf("original value of the matrix\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf(" %d\t",mat[i][j]);
}
	printf("\n");
}
for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			transpose[i][j]=mat[i][j];
		}
	}
		for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d",transpose[i][j]);
		}
		printf("\n");
}
}
	
