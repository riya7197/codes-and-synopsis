#include<stdio.h>
int main()
{
	int i,j,k,r1,c1,r2,c2,tot=0;
	int a[i][j],b[i][j],c[i][j];
	printf("enter the rows and columns of first matrix\t");
	scanf("%d%d",&r1,&c1);
	printf("enter the rows and columns of second matrix\t");
	scanf("%d%d",&r2,&c2);
	 
	 if(c1!=r1)
	 {
	 	printf("multiplication is not possible ");
	 }
	 else
	 {
	 	printf("enter the elements of first matrix");
	 	for(i=0;i<r1;i++)
	 	{
	 		for(j=0;j<c1;j++)
	 		{
	 			printf("index value [%d][%d]",i,j);
	 			scanf("%d",&a[i][j]);
			 }
		 }
		 printf("enter the elements of second  matrix");
	 	for(i=0;i<r2;i++)
	 	{
	 		for(j=0;j<c2;j++)
	 		{
	 			printf("index value [%d][%d]",i,j);
	 			scanf("%d",&b[i][j]);
			 }
		 }
		 printf("matrix a is :\n");
		 for(i=0;i<r1;i++)
	 	{
	 		for(j=0;j<c1;j++)
	 		{
	 			printf("%d",a[i][j]);
	 		}
	 		printf("\n");
	 	}
	 	printf("matrix b is :\n");
		 for(i=0;i<r2;i++)
	 	{
	 		for(j=0;j<c2;j++)
	 		{
	 			printf("%d",b[i][j]);
	 		}
	 		printf("\n");
	 	}
	 	for(i=0;i<r1;i++)
	 	{
	 		for(j=0;j<c2;j++)
	 		{
	 			for(k=0;k<r1;k++)
	 			{
	 				tot=tot+a[i][j]*b[i][j];
				 }
				 c[i][j]=tot;
				 tot=0;
			 }
		 }
		 for(i=0;i<r1;i++)
		 {
		 	for(j=0;j<c2;j++)
		 	{
		 		printf("%d",c[i][j]);
		 		
			 }
			 printf("\n");
		 }
	 }
}
