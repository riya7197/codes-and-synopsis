#include<iostream>
using namespace std;
class add
{
    public:
    add(int a)
    {
    	int x;
    	x=a;
    	cout<<x;
	}
	add(int x,int y)
	{
		int a ,b;
		a=x;
		b=y;
		cout<<x*y;
	}
	void show()
	{
		cout<<"ener c and y";
	}
};
int main()
{
	add ob(3);
	add ob(3,4);
	ob.show();
	
}
