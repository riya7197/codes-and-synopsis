#include<stdio.h>
int main()
{
	int i,j;
	int a[3][3],b[3][3],c[3][3];
	printf("enter the elements of first matrix\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("index value at[%d][%d]",i,j);
			scanf("%d",&a[i][j]);
		}
	}
	printf("enter the elements of 2nd matrix\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("index value at[%d][%d]",i,j);
			scanf("%d",&b[i][j]);
		}
	}
	printf("matrix a is :\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
	printf("matrix b is :\n");
		for(i=0;i<3;i++)
		{
		for(j=0;j<3;j++)
		{
			printf("%d\t",b[i][j]);
		}
		printf("\n");
	}
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			c[i][j]=a[i][j]+b[i][j];	
		}
	}
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d\t",c[i][j]);
		}
		printf("\n");
	}
}
+	
		

