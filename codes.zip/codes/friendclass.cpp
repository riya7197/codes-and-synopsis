#include<iostream>
using  namespace std;
 class class1
 {
 	private :
 		int a,b;
 		void get()
		 {
 			cout<<"enter the value of a"<<endl;
 			cin>>a>>b;
 	
		 }
 		friend class class2;
 };
 
	class class2 
	{
		public:
			void disp(class1 &ob){
			
			ob.get();
			cout<<ob.a;
			cout<<ob.b;
			
		}
	};
	int main()
	{
		class1 ob1;
		class2 ob2;
		ob1.get();
		ob2.disp(ob1);
	}
