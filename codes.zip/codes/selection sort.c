#include<stdio.h>
int main()
{
    int a[20],n,i,j,min;
    printf("enter the size of the array:");
    scanf("%d",&n);
     
     for(i=0;i<n;i++)
     {
         printf("index value %d",i);
         printf("enter the values of the element\n");
         scanf("%d",&a[i]);
         
         for(i=0;i<n-1;i++)
         {
             int min=i;
             for(j=i+1;j<n;j++)
             {
                 if(a[j]<a[min])
                 {
                     min=j;
                 }
             }
         }
         if(min !=i)
         {
             swap (a[i] && a[min]);
         }
         for(i=0;i<n-1;i++)
         {
             for(j=i+1;j<n;j++)
             {
                 printf("%d",a[i]);
             }
            printf("\n");
             return 0;
         }
     }
 }
