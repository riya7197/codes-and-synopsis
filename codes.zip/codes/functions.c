#include<stdio.h>
int main()
{
	int max();
	max();
	getch();
}
	int max()
	{
	int a=20,b=30,c;
	printf("value of a is:%d and b is:%d",a,b);
	if(a>b)
	{
		c=a;
	}
	else
	{
		c=b;
	}
	printf("value of c is :%d",c);
	return 0;
}
