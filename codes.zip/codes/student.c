#include<stdio.h>
 
 struct student
 {
     char name[10];
     int roll;
     long phone;
     int marks;
 };
 void main()
 {
 int i,marks;
 struct student s[3];
 for(i=0;i<3;i++)
 {
    printf("enter name :");
    scanf("%s",&s[i].name);
    printf("enter roll :");
    scanf("%d",&s[i].roll);
    printf("enter phone :");
    scanf("%d",&s[i].phone);
    printf("enter marks :");
    scanf("%d",&s[i].marks);
}
printf(" employee details \n");
for(i=0;i<3;i++)
{
	printf("name is %s:\n",s[i].name);
	printf("roll no is %d\n: ",s[i].roll);
	printf("phone is :%d\n",s[i].phone);
	printf("marks is :%d\n",s[i].marks);
}
if (marks >80)
{
    printf("excellent grade\n");
}
else if(marks>40)
{
    printf("need to work hard\n");
}
else
{
    printf("better luck next time ");
}

}
