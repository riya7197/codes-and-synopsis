#include<stdio.h>
int main()
{
	struct college
	{
		char name[40];
		int phone;
		
		struct student
		{
		char nam[20];
		int age,roll;	
		};
	};
	{
	
	struct college b1={"cu college",2222122};
	struct college b2={"pu university",56163203};
	struct student s1={"riya",10,5624};
	struct student s2={"sneha",2,5247521};
	printf("display the details of %s%d\n",b1.name,b1.phone);
	printf("display the details of %s %d\n",b2.name,b2.phone);
	printf("display the stuent details =%s%d%d\n",s1.nam,s1.age,s1.roll);
	printf("display the student details=%s%d%d\n",s2.nam,s2.age,s2.roll);
	};
}
