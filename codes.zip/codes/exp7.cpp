#include <iostream>
using namespace std;


class Number 
{
private:
    int x; // Non-static data member
    static int y; // Static data member

public:
    int get(int a,int b)
    {
    	x=a;
    	y=b;
	}
    
    // Function to display both non-static and static numbers
    void display() 
	{
        cout << "Non-static Number: " << x << endl;
        cout << "Static Number: " << y << endl;
    }

    // Function to increment both non-static and static numbers
    void increment() 
	{
        x++;
        y++;
    }
};

// Initializing the static member
int Number::y;

int main() 
{
	int i;
   Number ob[5];
   for(i=0;i<5;i++)
   {
   	ob[i].get(2,5);
   	ob[i].display();
   	ob[i].increment();
   }
   return 0;
}
