#include<iostream>
using namespace std;
class demo
{
	private :
		int feet;
		float inches;
		public:
		demo();
			
		
			demo(int f,float i)
			{
				feet=f;
				inches=i;
			}
			void show()
			{
				cout<<"height in feets and inches is :"<<feet<<"'"<<inches<<endl;
			}
			void add_height(demo d1,demo d2)
			{
				feet=0;
				
				inches=0;
				inches=d1.inches+d2.inches;
				while(inches>=12)
				{
					inches-=12;
					feet++;
					
				}
				feet+=d1.feet+d2.feet;
			}
};
int main()
{
	demo d1(5,11);
	demo d2(6,3);
	demo d3;
	d3.add_height(d1,d2);
	d3.show();
	demo d4;
	d4.add_height();
}
