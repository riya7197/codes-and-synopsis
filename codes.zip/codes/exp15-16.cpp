#include<iostream>
using namespace std;
int add(int a,int b)
{
	return (a+b);
}
int sub(int a,int b)
{
	return(a-b);
}
int main()
{
	cout<<"Name:riya"<<endl;
	cout<<"Roll no:2210997197"<<endl;
	int(*fun) (int,int);
	fun=add;
	int result=fun(5,10);
	cout<<"Result of addition is:"<<result<<endl;
	fun=sub;
	result=fun(10,8);
	cout<<"Result of subtraction is:"<<result<<endl;
}
