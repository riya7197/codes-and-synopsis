#include<iostream>
using namespace std;
class student
{
	public: 
		int data;
		student(int data)
		{
			this->data=data;
		}
		int print()
		{
			cout<<"Data:"<<this->data<<endl;
		}
		int setdata(int data)
		{
			this->data=data;
		}
		int display()
		{
			cout<<"Address of object"<<this<<endl;
		}
};
int main()
{
	cout<<"name:riya"<<endl;
	cout<<"roll no :2210997197"<<endl;
	cout<<endl;
	cout<<endl;
	
	student ob1(50);
	student ob2(70);
	ob1.print();
	ob2.print();
	ob1.setdata(90);
	ob1.print();
	ob1.display();
	ob2.display();
}
