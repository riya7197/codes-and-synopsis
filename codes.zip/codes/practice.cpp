#include<iostream>
using namespace std;
class demo
{
	public:
		demo()
		{
			int * ptr=new int(6);
		}
	};
	int main()
	{
		demo ob;
		
	}
	
