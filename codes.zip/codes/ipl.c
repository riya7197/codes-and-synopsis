#include<stdio.h>
int main()
{
	int a,i;
	a=6;
	i=1;
	do
	{
		printf("%d",a*i);
		i++;
		
	}
	while(i<=10);
	return 0;
}
	

