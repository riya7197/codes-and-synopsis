#include<iostream>
#include<string>
using namespace std;
class employee
{
	public:
		string name;
		int empid,salary;
		employee()
		{
			cout<<"DEFAULT CONSTRUCTOR"<<endl;
			
			cout<<"enter name:";
			cin>>name;
			cout<<"enter id:";
			cin>>empid;
			cout<<"enter salary:";
			cin>>salary;
			cout<<"Name:"<<name<<endl;
			cout<<"ID:"<<empid<<endl;
			cout<<"Salary:"<<salary<<endl;
		}
		employee(string n,int id,int sal)
		{
			name=n;
			empid=id;
			salary=sal;
			cout<<"\nPARAMETERISED CONSTRUCTOR"<<endl;
			cout<<"Name:"<<n<<endl;
			cout<<"ID:"<<id<<endl;
			cout<<"Salary:"<<sal<<endl;
		}
		employee (employee &ob)
		{
			name=ob.name;
			empid=ob.empid;
			salary=ob.salary;
			cout<<"\nCOPY CONSTRUCTOR"<<endl;
			cout<<"Name:"<<name<<endl;
			cout<<"ID:"<<empid<<endl;
			cout<<"Salary:"<<salary<<endl;
		}
		~employee()
		{
			cout<<"\nDESTRUCTOR HAS BEEN CALLED"<<endl;
		}
};
int main()
{
	cout<<"Name: riya"<<endl;
	cout<<"Roll no:2210997197"<<endl;
	employee obj;
	employee ob1("sneha",1001,20000);
	employee ob2(ob1);
}
