#include<stdio.h>
int main()
{
int r1,c1,r2,c2,i,j,k,tot=0;
int frt[10][10],sec[10][10],mul[10][10];
printf("enter the row and columns of first matrix\n");
scanf("%d%d",&r1,&c1);
printf("enter the row and columns of second matrix\n");
scanf("%d%d",&r2,&c2);
if(c1!=r2)
{
	printf("given matrix can not be multiply\n");
}
else
{
	printf("insert elements of first matrix\n");
	for(i=0;i<r1;i++)
	{
		for(j=0;j<c1;j++)
		{
			printf("enter frt[i][j]",i,j);
			scanf("%d",&frt[i][j]);
		}
	}
	for(i=0;i<r1;i++)
	{
		printf("\n");
	    for(j=0;j<c1;j++)
	    {
	    	printf("%d\t",frt[i][j]);
		}
	}
    printf("\ninsert elements of second matrix\n");
	for(i=0;i<r2;i++)
	{
		for(j=0;j<c2;j++)
		{
			printf("enter sec[i][j]",i,j);
			scanf("%d",&sec[i][j]);
		}
	}
	for(i=0;i<r2;i++)
	{
		printf("\n");
	    for(j=0;j<c2;j++)
	    {
	    	printf("%d\t",sec[i][j]);
		}
	}
	for(i=0;i<r1;i++)
	{
		for(j=0;j<c2;j++)
		{
			for(k=0;k<r1;k++)
			{
				tot=tot+frt[i][k]*sec[k][j];
			}
			mul[i][j]=tot;
			tot=0;
		}
	}
	printf("\nmultiplication of two matrix is:\n");
	for(i=0;i<r1;i++)
	{
		printf("\n");
		for(j=0;j<c2;j++)
		{
			printf("%d\t",mul[i][j]);
		}
	}
	
}
return 0;
}
