void main()
{
File*pf;
char name[30]=�Chandigarh";
pf=fopen("gur.txt","w");
fprintf(pf,"%s",name);
printf("Data entered");
getch();
}

