#include<iostream>
using namespace std;
class A
{
	private:
	int a,b;
	public:
	void get()
	{
		cout<<"enter the value of  a and b "<<endl;	//5
		cin>>a>>b;									//10
		}
		void disp()
		{
			cout<<"value of a is :"<<a<<endl;		//5
			cout<<"value of b is :"<<b<<endl;		//10
}
	friend int  sum(A &ob);
};
	
		int sum(A &ob)
		{
			ob.a=ob.a+10;							//15
			ob.b=ob.b+10;							//20
		}
		int main()
		{
			A ob1;
			ob1.get();	//5
			ob1.disp();	//10
			sum(ob1);
			ob1.disp();	//15,25
		}
