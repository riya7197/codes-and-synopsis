class preetyyou
{
    public static void main(string[40])
    {
        system.out.printfln("you are preety just the way you are");
        system.out.printfln("hello preetylady");
    }
}
