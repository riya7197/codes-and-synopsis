#include<stdio.h>
void main()
{
    char ch[10];
    
    printf("enter the 1st string:\t");
    gets(ch);
    printf("%s",ch);
    printf("\nthe  string is:%s",strlow(ch));
}
    
