#include<stdio.h>
int main()
{
	int i,j,r1,c1,r2,c2,k;
	int a[i][j],b[i][j],c[i][j];
	
	
	printf("enter the rows  and columns of first matrix");
	scanf("%d%D",&r1,&c1);
	printf("enter the rows and columns of 2nd matrix");
	scanf("%d%d",&r2,&c2);
	
	if(c1!=r2)
	{
		printf("multiplication of these matrixes is not possible");
		exit(0);
	}
	
	printf("enter the elements of 1st matrix\n");
	for(i=0;i<r1;i++)
	{
		for(j=0;j<c1;j++)
		{
			printf("index value [%d][%d]=",i,j);
			scanf("%d",&a[i][j]);
		}
	}
	printf("enter the elements of 2nd matrix\n");
	for(i=0;i<r2;i++)
	{
		for(j=0;j<c2;j++)
		{
			printf("index value [%d][%d]=",i,j);
			scanf("%d",&b[i][j]);
}
}
printf("matrix a is :\n");
for(i=0;i<r1;i++)
	{
		for(j=0;j<c1;j++)
		{
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
	printf("matrix b is :\n");
	for(i=0;i<r2;i++)
	{
		for(j=0;j<c2;j++)
		{
			printf("%d\t",b[i][j]);
		}
		printf("\n");
}
	for(i=0;i<r1;i++)
	{
		for(j=0;j<c2;j++)
		{
			
				int sum=0;
				for(k=0;k<c1;k++)
				{
					sum=sum+a[i][k]+b[k][j];
					c[i][j]=sum;
					sum=0;
				}
		}
		}
	printf("multiplication of the matrixes is :");
	 
	 for(i=0;i<r1;i++)
	 {
	 	for(j=0;j<c2;j++)
	 	{
	 		printf("%d",c[i][j]);
		 }
		 printf("\n");
	 }
	 
}
