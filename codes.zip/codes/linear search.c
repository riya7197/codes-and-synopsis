#include<stdio.h>
int main()
{
	int found= 0;
	int a[10],n,i,data;
	
	printf("enter the size of the array");
	scanf("%d",&n);
	
	printf("enter the data you wanna find :\n");
	scanf("%d",&data);
	
	for(i=0;i<n;i++)
	{
		printf("value at index [%d]:",i);
		scanf("%d",&a[i]);
		if(a[i]==data)
		{
			printf("index value of the data is :%d/n",i);
			break;
		}
	}
	if(found==0)
	{
		printf("element is not found");
	}
	return 0;
}
