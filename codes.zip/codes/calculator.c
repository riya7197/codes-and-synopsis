#include<stdio.h>
int main()
{
	int choice ;
	int a,b,c;
	printf("enter your choice :\n1 add \n2 subtraction \n3 multiplication \n4 division\n");
	scanf("%d",&choice);
	
	switch(choice)
	{
		case 1:
			printf("you selected for addition\n");
			printf("enter two numbers\n");
			scanf("%f%f",&a,&b);
			c=a+b;
			printf("adddtion is :%f",c);
			break;
			
				case 2:
			printf("you selected for subtraction\n");
			printf("enter two numbers\n");
			scanf("%f%f",&a,&b);
			c=a-b;
			printf("subtraction is :%f",c);
			break;
			
			
				case 3:
			printf("you selected for multiplication\n");
			printf("enter two numbers\n");
			scanf("%f%f",&a,&b);
			c=a*b;
			printf("multiplication is :%f",c);
			break;
			
			
				case 4:
			printf("you selected for division\n");
			printf("enter two numbers\n");
			scanf("%f%f",&a,&b);
			c=a/b;
			printf("division is :%f",c);
			break;
			
			default:
				printf("wrong choice \n");
			
	}
	return 0;
}

