#include <iostream>

// Base class with a pure virtual function
class Shape {
public:
    // Pure virtual function
    virtual void draw() const = 0;
    
    // Regular member function
    void printName() const {
        std::cout << "This is a Shape." << std::endl;
    }
};

// Derived class providing an implementation for the pure virtual function
class Circle : public Shape {
public:
    // Implementation of the pure virtual function
    void draw() const override {
        std::cout << "Drawing a Circle." << std::endl;
    }
};

// Another derived class providing a different implementation for the pure virtual function
class Square : public Shape {
public:
    // Implementation of the pure virtual function
    void draw() const override {
        std::cout << "Drawing a Square." << std::endl;
    }
};

int main() {
    Circle circle;
    Square square;

    // Using the draw function through the base class pointer
    Shape* shapePtr = &circle;
    shapePtr->draw();

    shapePtr = &square;
    shapePtr->draw();

    // Using the printName function from the base class
    circle.printName();
    
    
    
    
    
    
    
    
    
    
    
    square.printName();

    return 0;
}
