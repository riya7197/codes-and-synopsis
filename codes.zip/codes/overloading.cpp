#include<iostream>
using namespace std;
class fun
	{
		public:
			int get(int x,int y)
			{
				int a,b;
				a=x;
				b=y;
				cout<<a*b<<endl;
				
			}
			int get(double a)
			{
				double b;
				cout<<b<<endl;
			}
		};
		int main()
		{
			fun obj;
			obj.get(3,4);
			obj.get(4.5);
		}

	
